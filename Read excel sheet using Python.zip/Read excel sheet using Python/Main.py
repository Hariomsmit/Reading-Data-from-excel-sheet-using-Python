#AUTHOR- HARI OM
#Importing xlrd==1.2.0 version
import xlrd
#Store Path of your excel sheet file in "loc" variable.
loc=("X:\\GItHub\\Read excel sheet using Python\\Book.xlsx")
obj=xlrd.open_workbook(loc)
page=obj.sheet_by_index(0)
page.cell_value(0,0)
for i in range(0,8):#Write the number of rows you want to print
                    #Here I want to print first 9 rows so "range(0,8)"
                    #Here 0 in range function will print the title of the table
    print(page.row_values(i))




